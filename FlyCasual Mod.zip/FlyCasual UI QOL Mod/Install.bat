@echo off
setlocal EnableExtensions EnableDelayedExpansion
title FlyCasual UI QOL Mod - Installer
echo.
echo  ==========================================
echo   FlyCasual UI QOL Mod v1.0.0 - Installer
echo  ==========================================
echo.

set "SRC=%~dp0Game Files"
if not exist "%SRC%\BepInEx\plugins\FlyCasualQoL\FlyCasualQoL.dll" (
    echo  ERROR: "Game Files" folder not found next to this installer.
    echo  Keep Install.bat in the same folder as "Game Files".
    goto :fail
)

set "DEFAULT=Z:\Third Party Games\Star Wars Board Games\FlyCasual"
set "GAME="
if exist "%DEFAULT%\Fly Casual.exe" (
    echo  Found Fly Casual at:
    echo    %DEFAULT%
    set /p "USEDEF=  Install there? [Y/n]: "
    if /i not "!USEDEF!"=="n" set "GAME=%DEFAULT%"
)
if not defined GAME (
    echo.
    echo  Paste the folder that contains "Fly Casual.exe" and press Enter:
    set /p "GAME=  > "
)
set "GAME=%GAME:"=%"
if "%GAME:~-1%"=="\" set "GAME=%GAME:~0,-1%"

if not exist "%GAME%\Fly Casual.exe" (
    echo.
    echo  ERROR: "Fly Casual.exe" was not found in:
    echo    %GAME%
    goto :fail
)

tasklist /FI "IMAGENAME eq Fly Casual.exe" 2>nul | find /I "Fly Casual.exe" >nul
if not errorlevel 1 (
    echo.
    echo  Fly Casual is running. Close the game, then press any key to continue.
    pause >nul
    tasklist /FI "IMAGENAME eq Fly Casual.exe" 2>nul | find /I "Fly Casual.exe" >nul
    if not errorlevel 1 ( echo  Game is still running. & goto :fail )
)

if exist "%GAME%\BepInEx\config\BepInEx.cfg" (
    echo.
    echo  Existing BepInEx install detected. Your BepInEx.cfg will be kept,
    echo  but its entrypoint is switched to "Camera" so it does not hang on startup.
    echo  A backup is saved as BepInEx.cfg.bak
    copy /Y "%GAME%\BepInEx\config\BepInEx.cfg" "%GAME%\BepInEx\config\BepInEx.cfg.bak" >nul
    robocopy "%SRC%" "%GAME%" /E /XF BepInEx.cfg /NFL /NDL /NJH /NJS /NP >nul
    set "RC=!errorlevel!"
    powershell -NoProfile -Command "$p='%GAME%\BepInEx\config\BepInEx.cfg'; (Get-Content -LiteralPath $p) -replace '^Type = Application','Type = Camera' | Set-Content -LiteralPath $p"
) else (
    robocopy "%SRC%" "%GAME%" /E /NFL /NDL /NJH /NJS /NP >nul
    set "RC=!errorlevel!"
)
if !RC! GEQ 8 (
    echo  ERROR: copying files failed.
    goto :fail
)

echo.
echo  Installed to:
echo    %GAME%
echo.
echo  Start Fly Casual. Press F8 in game to open the mod settings.
echo.
pause
exit /b 0

:fail
echo.
echo  Installation was NOT completed.
pause
exit /b 1
