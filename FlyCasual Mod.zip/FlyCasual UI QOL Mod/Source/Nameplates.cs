using System.Collections.Generic;
using MainPhases;
using Players;
using Ship;
using UnityEngine;
using UnityEngine.UI;

namespace FlyCasualQoL
{
    // Ship labels drawn on the overlay canvas (under the game's HUD).
    // Default: hidden until a ship is hovered; attack participants also show during combat.
    public class Nameplates : MonoBehaviour
    {
        private class Plate
        {
            public RectTransform root;
            public CanvasGroup group;
            public Image bg, strip, edgeTop, edgeBottom, barBg, barHull, barShield;
            public Text l1, l2, l3;
            public float alpha;
            public bool seen;
        }

        private readonly Dictionary<GenericShip, Plate> plates = new Dictionary<GenericShip, Plate>();
        private readonly List<GenericShip> stale = new List<GenericShip>();
        private readonly List<(Plate p, Rect r, bool emph)> placed = new List<(Plate, Rect, bool)>();
        private Camera cam;
        private bool errorLogged;
        private int builtSize = -1;

        internal static Color PlayerColor(GenericShip ship)
        {
            bool p1 = ship.Owner != null && ship.Owner.PlayerNo == PlayerNo.Player1;
            if (Plugin.ColorblindPalette.Value)
                return p1 ? new Color(0.35f, 0.65f, 1f) : new Color(1f, 0.6f, 0.15f);
            return p1 ? new Color(0.30f, 0.85f, 0.40f) : new Color(1f, 0.35f, 0.35f);
        }

        internal static Camera GetCam(ref Camera cache)
        {
            if (cache != null && cache.isActiveAndEnabled) return cache;
            var go = GameObject.Find("CameraHolder/Main Camera");
            cache = go != null ? go.GetComponent<Camera>() : Camera.main;
            return cache;
        }

        private static string Trunc(string s, int n) => string.IsNullOrEmpty(s) ? "" : (s.Length <= n ? s : s.Substring(0, n - 1) + "…");

        private void LateUpdate()
        {
            if (!Plugin.TypingInField() && Input.GetKeyDown(Plugin.ToggleNameplatesKey.Value))
                Plugin.NameplatesEnabled.Value = !Plugin.NameplatesEnabled.Value;
            try { Tick(); }
            catch (System.Exception e)
            {
                if (!errorLogged) { Plugin.Log.LogWarning("Nameplates: " + e); errorLogged = true; }
            }
        }

        private Plate Create()
        {
            var p = new Plate();
            var go = new GameObject("Plate", typeof(RectTransform));
            go.transform.SetParent(Overlay.Rect, false);
            p.root = (RectTransform)go.transform;
            p.root.anchorMin = p.root.anchorMax = new Vector2(0.5f, 0.5f);
            p.root.pivot = new Vector2(0.5f, 0f);
            p.group = go.AddComponent<CanvasGroup>();
            p.group.blocksRaycasts = false;
            p.group.interactable = false;
            p.bg = Overlay.NewImage(p.root, "bg");
            p.strip = Overlay.NewImage(p.root, "strip");
            p.edgeTop = Overlay.NewImage(p.root, "edgeTop");
            p.edgeBottom = Overlay.NewImage(p.root, "edgeBottom");
            p.barBg = Overlay.NewImage(p.root, "barBg");
            p.barHull = Overlay.NewImage(p.root, "barHull");
            p.barShield = Overlay.NewImage(p.root, "barShield");
            int size = Plugin.NameplateFontSize.Value;
            p.l1 = Overlay.NewText(p.root, "l1", size, FontStyle.Bold);
            p.l2 = Overlay.NewText(p.root, "l2", Mathf.Max(8, size - 2), FontStyle.Normal);
            p.l3 = Overlay.NewText(p.root, "l3", Mathf.Max(8, size - 2), FontStyle.Normal);
            p.group.alpha = 0;
            return p;
        }

        private void DestroyAll()
        {
            foreach (var p in plates.Values) if (p.root != null) Destroy(p.root.gameObject);
            plates.Clear();
        }

        private void Tick()
        {
            if (!Plugin.NameplatesEnabled.Value || Roster.AllUnits == null || Roster.AllUnits.Count == 0 || GetCam(ref cam) == null)
            {
                if (plates.Count > 0) DestroyAll();
                return;
            }
            if (builtSize != Plugin.NameplateFontSize.Value) { DestroyAll(); builtSize = Plugin.NameplateFontSize.Value; }

            var mode = Plugin.NameplateStyle.Value;
            bool alt = UI.ShowShipIds;
            var phase = Phases.CurrentPhase;
            bool activation = phase is ActivationPhase;
            bool combat = phase is CombatPhase;

            foreach (var p in plates.Values) p.seen = false;
            placed.Clear();

            foreach (var kv in Roster.AllUnits)
            {
                var ship = kv.Value;
                if (ship == null || ship is Remote.GenericRemote || ship.IsDestroyed || ship.Model == null) continue;

                bool hovered = ship == Selection.HoveredShip;
                bool combatPair = combat && (ship == Selection.ThisShip || ship == Selection.AnotherShip || ship == Combat.Attacker || ship == Combat.Defender);
                bool emphasis = hovered || combatPair;
                bool visible = mode == NameplateMode.Always || alt || (mode == NameplateMode.HoverOnly && emphasis);

                if (!plates.TryGetValue(ship, out var p))
                {
                    if (!visible) continue;
                    p = Create();
                    plates[ship] = p;
                }
                p.seen = true;

                float target = visible ? 1f : 0f;
                bool dim = Plugin.DimActivatedShips.Value && !emphasis &&
                           ((activation && ship.IsManeuverPerformed) || (combat && (ship.IsAttackPerformed || ship.IsActivatedDuringCombat)));
                if (visible && dim) target = 0.5f;
                p.alpha = Mathf.MoveTowards(p.alpha, target, Time.unscaledDeltaTime * 8f);
                p.group.alpha = p.alpha;
                bool show = p.alpha > 0.01f;
                if (p.root.gameObject.activeSelf != show) p.root.gameObject.SetActive(show);
                if (!show) continue;

                Vector3 sp = cam.WorldToScreenPoint(ship.GetCenter() + Vector3.up * 0.35f);
                if (sp.z <= 0f || !Overlay.ScreenToLocal(sp, out var local)) { p.root.gameObject.SetActive(false); continue; }

                Fill(p, ship, emphasis || alt || mode == NameplateMode.Always, emphasis, activation, combat);
                var size = p.root.sizeDelta;
                placed.Add((p, new Rect(local.x - size.x / 2, local.y, size.x, size.y), emphasis));
            }

            // De-overlap in canvas space: emphasised plates keep their spot, others stack upward.
            placed.Sort((a, b) => a.emph != b.emph ? (a.emph ? -1 : 1) : a.r.y.CompareTo(b.r.y));
            for (int i = 0; i < placed.Count; i++)
            {
                var r = placed[i].r;
                for (int guard = 0; guard < 12; guard++)
                {
                    bool moved = false;
                    for (int j = 0; j < i; j++)
                        if (r.Overlaps(placed[j].r)) { r.y = placed[j].r.yMax + 2; moved = true; }
                    if (!moved) break;
                }
                placed[i] = (placed[i].p, r, placed[i].emph);
                placed[i].p.root.anchoredPosition = new Vector2(r.center.x, r.y);
            }

            stale.Clear();
            foreach (var kv in plates) if (!kv.Value.seen || kv.Key.IsDestroyed) stale.Add(kv.Key);
            foreach (var s in stale) { if (plates[s].root != null) Destroy(plates[s].root.gameObject); plates.Remove(s); }
        }

        private void Fill(Plate p, GenericShip ship, bool full, bool emphasis, bool activation, bool combat)
        {
            var st = ship.State;
            Color pc = PlayerColor(ship);
            string pilot = ship.PilotInfo != null ? ship.PilotInfo.PilotName : ship.PilotName;

            p.l1.text = "#" + ship.ShipId + "  " + Trunc(pilot, full ? 28 : 18) + (full ? "" : "   I" + st.Initiative);
            p.l1.color = Color.Lerp(Color.white, pc, 0.4f);
            p.l2.gameObject.SetActive(full);
            p.l3.gameObject.SetActive(full);

            float pad = 8, y = 3;
            float w = p.l1.preferredWidth;
            float lh1 = p.l1.fontSize + 4, lh2 = p.l2.fontSize + 3;
            Overlay.Place(p.l1.rectTransform, pad, y, w + 4, lh1);
            y += lh1;

            if (full)
            {
                string type = ship.ShipInfo != null ? ship.ShipInfo.ShipName : "";
                p.l2.text = Trunc(type, 30) + "  ·  Init " + st.Initiative;
                p.l2.color = new Color(0.85f, 0.87f, 0.9f);
                var parts = new List<string> { "Hull " + st.HullCurrent + "/" + st.HullMax };
                if (st.ShieldsMax > 0) parts.Add("Shd " + st.ShieldsCurrent + "/" + st.ShieldsMax);
                if (st.MaxForce > 0) parts.Add("Frc " + st.Force + "/" + st.MaxForce);
                if (ship.IsStressed) parts.Add("STRESSED");
                if (st.IsIonized) parts.Add("IONIZED");
                if (activation && ship.IsManeuverPerformed) parts.Add("moved");
                if (combat && ship.IsAttackPerformed) parts.Add("attacked");
                p.l3.text = string.Join("   ", parts);
                p.l3.color = ship.IsStressed ? new Color(1f, 0.6f, 0.6f) : new Color(0.85f, 0.87f, 0.9f);
                w = Mathf.Max(w, p.l2.preferredWidth, p.l3.preferredWidth);
                Overlay.Place(p.l2.rectTransform, pad, y, w + 4, lh2); y += lh2;
                Overlay.Place(p.l3.rectTransform, pad, y, w + 4, lh2); y += lh2;
            }

            float width = w + pad * 2, barY = y + 2, height = barY + 6;
            p.root.sizeDelta = new Vector2(width, height);

            p.bg.color = new Color(0.05f, 0.06f, 0.08f, emphasis ? 0.85f : 0.65f);
            Overlay.Place(p.bg.rectTransform, 0, 0, width, height);
            p.strip.color = pc;
            Overlay.Place(p.strip.rectTransform, 0, 0, emphasis ? 4 : 3, height);
            p.edgeTop.enabled = p.edgeBottom.enabled = emphasis;
            p.edgeTop.color = p.edgeBottom.color = pc;
            Overlay.Place(p.edgeTop.rectTransform, 0, 0, width, 1);
            Overlay.Place(p.edgeBottom.rectTransform, 0, height - 1, width, 1);

            int total = Mathf.Max(1, st.HullMax + st.ShieldsMax);
            float bw = width - pad * 2;
            float hw = bw * st.HullCurrent / total, sw = bw * st.ShieldsCurrent / total;
            p.barBg.color = new Color(0.25f, 0.25f, 0.28f);
            Overlay.Place(p.barBg.rectTransform, pad, barY, bw, 3);
            p.barHull.color = new Color(1f, 0.82f, 0.25f);
            Overlay.Place(p.barHull.rectTransform, pad, barY, hw, 3);
            p.barShield.color = new Color(0.35f, 0.7f, 1f);
            Overlay.Place(p.barShield.rectTransform, pad + hw, barY, sw, 3);
        }
    }
}
