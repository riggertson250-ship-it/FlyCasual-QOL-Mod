using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using HarmonyLib;
using MainPhases;
using Movement;
using Players;
using Ship;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Rendering;
using UnityEngine.UI;

namespace FlyCasualQoL
{
    // Captures the temporary ship stands a prediction generates, so the ghost can draw the flight path.
    [HarmonyPatch(typeof(MovementPrediction), "GenerateShipStands")]
    internal static class Patch_CaptureStands
    {
        internal static readonly Dictionary<MovementPrediction, List<Pose>> Captured = new Dictionary<MovementPrediction, List<Pose>>();
        private static readonly AccessTools.FieldRef<MovementPrediction, GameObject[]> Stands =
            AccessTools.FieldRefAccess<MovementPrediction, GameObject[]>("GeneratedShipStands");

        private static void Postfix(MovementPrediction __instance)
        {
            if (!Captured.ContainsKey(__instance)) return;
            var list = new List<Pose>();
            var arr = Stands(__instance);
            if (arr != null)
                foreach (var go in arr)
                    if (go != null) list.Add(new Pose(go.transform.position, go.transform.rotation));
            Captured[__instance] = list;
        }
    }

    public class ManeuverPreview : MonoBehaviour
    {
        private static readonly Regex ManeuverName = new Regex(@"^[0-5]\.[FLRS]\.[A-Za-z]$");

        private class Ghost
        {
            public GameObject root;
            public Vector3 labelPos;
            public string title;
            public string outcome;
            public Color color;
            public bool ready;
        }

        private struct Request { public GenericShip ship; public string key; public GenericMovement copyFrom; }

        private readonly Dictionary<string, Ghost> cache = new Dictionary<string, Ghost>();
        private readonly HashSet<string> wanted = new HashSet<string>();
        private readonly Queue<Request> queue = new Queue<Request>();
        private readonly List<RaycastResult> hits = new List<RaycastResult>();
                private bool working;
        private float boardHash;
        private float lastOpacity = -1;
        private Camera cam;
        private bool errorLogged;

        private static readonly Color ColClear = new Color(0.35f, 0.9f, 1f);
        private static readonly Color ColBump = new Color(1f, 0.85f, 0.2f);
        private static readonly Color ColHazard = new Color(1f, 0.55f, 0.15f);
        private static readonly Color ColFail = new Color(1f, 0.25f, 0.25f);

        private void Update()
        {
            try { Tick(); }
            catch (Exception e)
            {
                if (!errorLogged) { Plugin.Log.LogWarning("ManeuverPreview: " + e); errorLogged = true; }
            }
        }

        private void Tick()
        {
            wanted.Clear();
            if (!Plugin.ManeuverPreview.Value || Roster.AllUnits == null) { ApplyVisibility(); return; }

            if (Mathf.Abs(lastOpacity - Plugin.GhostOpacity.Value) > 0.001f) { lastOpacity = Plugin.GhostOpacity.Value; ClearCache(); }

            // Invalidate when anything on the board has moved.
            float h = 0;
            foreach (var kv in Roster.AllUnits)
            {
                var s = kv.Value;
                if (s == null || s.Model == null) continue;
                var p = s.GetPosition();
                var r = s.GetAngles();
                h += p.x * 1.31f + p.z * 2.17f + r.y * 0.013f + s.ShipId;
            }
            if (Math.Abs(h - boardHash) > 0.0001f) { boardHash = h; ClearCache(); }

            // Hovered dial button.
            if (DirectionsMenu.IsVisible && Selection.ThisShip != null && EventSystem.current != null)
            {
                string key = HoveredManeuver();
                if (key != null) Want(Selection.ThisShip, key, null);
            }

            // Hold key in planning: all of your dialed ships.
            var phase = Phases.CurrentPhase;
            if (phase is PlanningPhase && !Plugin.TypingInField() && Input.GetKey(Plugin.ShowAllPlansKey.Value))
            {
                foreach (var kv in Roster.AllUnits)
                {
                    var s = kv.Value;
                    if (s == null || s is Remote.GenericRemote || s.IsDestroyed || !(s.Owner is HumanPlayer)) continue;
                    var m = s.AssignedManeuver;
                    if (m == null) continue;
                    Want(s, m.Speed + "." + m.Direction + "." + m.Bearing, m);
                }
            }

            ApplyVisibility();
            if (!working && queue.Count > 0) StartCoroutine(Process());
        }

        private string HoveredManeuver()
        {
            var ped = new PointerEventData(EventSystem.current) { position = Input.mousePosition };
            hits.Clear();
            EventSystem.current.RaycastAll(ped, hits);
            foreach (var hit in hits)
            {
                var t = hit.gameObject != null ? hit.gameObject.transform : null;
                for (int i = 0; i < 3 && t != null; i++, t = t.parent)
                    if (ManeuverName.IsMatch(t.name) && t.GetComponent<UnityEngine.UI.Button>() != null) return t.name;
            }
            return null;
        }

        private void Want(GenericShip ship, string key, GenericMovement copyFrom)
        {
            string id = ship.ShipId + "|" + key;
            wanted.Add(id);
            if (!cache.ContainsKey(id))
            {
                cache[id] = new Ghost();
                queue.Enqueue(new Request { ship = ship, key = key, copyFrom = copyFrom });
            }
        }

        private void ApplyVisibility()
        {
            foreach (var kv in cache)
                if (kv.Value.root != null) kv.Value.root.SetActive(wanted.Contains(kv.Key));
        }

        private void ClearCache()
        {
            foreach (var g in cache.Values) if (g.root != null) Destroy(g.root);
            cache.Clear();
            queue.Clear();
        }

        private IEnumerator Process()
        {
            working = true;
            while (queue.Count > 0)
            {
                var req = queue.Dequeue();
                string id = req.ship.ShipId + "|" + req.key;
                if (!cache.TryGetValue(id, out var ghost) || !wanted.Contains(id))
                {
                    cache.Remove(id);
                    continue;
                }
                // Never run alongside a real move or while the dial closes mid-calculation in other phases.
                if (!(DirectionsMenu.IsVisible || Phases.CurrentPhase is PlanningPhase)) { cache.Remove(id); continue; }

                GenericMovement mv = null;
                try
                {
                    mv = req.copyFrom != null ? ShipMovementScript.CopyMovement(req.copyFrom) : ShipMovementScript.MovementFromString(req.key, req.ship);
                    mv.TheShip = req.ship;
                    mv.Initialize();
                }
                catch (Exception e) { Plugin.Log.LogWarning("Preview setup failed for " + req.key + ": " + e.Message); cache.Remove(id); continue; }

                string title = Title(mv);
                string typeName = mv.GetType().Name;
                if (typeName.Contains("Reverse") || typeName.Contains("Sideslip"))
                {
                    ghost.title = title; ghost.outcome = "no preview for this maneuver type"; ghost.color = Color.gray;
                    ghost.labelPos = req.ship.GetCenter(); ghost.root = new GameObject("QoLGhost"); ghost.ready = true;
                    continue;
                }

                var pred = new MovementPrediction(req.ship, mv);
                Patch_CaptureStands.Captured[pred] = null;
                IEnumerator routine = StartPrediction(req.ship, mv, pred);
                if (routine != null)
                {
                    // Remaining steps only wait for physics and read results.
                    yield return routine.Current;
                    while (SafeMoveNext(routine, req.ship)) yield return routine.Current;
                }
                Patch_CaptureStands.Captured.TryGetValue(pred, out var poses);
                Patch_CaptureStands.Captured.Remove(pred);

                if (routine == null) { cache.Remove(id); continue; }
                if (!cache.ContainsKey(id)) continue; // invalidated while computing
                try { Build(ghost, req.ship, mv, pred, poses, title); }
                catch (Exception e) { Plugin.Log.LogWarning("Ghost build failed: " + e); cache.Remove(id); }
            }
            working = false;
        }

        // Runs the synchronous part of the game's prediction (stand placement). Curved maneuvers read
        // Selection.ThisShip.AssignedManeuver internally, so both are pointed at the preview for this
        // step only and restored before control returns to the game. Returns null on failure.
        private static IEnumerator StartPrediction(GenericShip ship, GenericMovement mv, MovementPrediction pred)
        {
            var prevSelected = Selection.ThisShip;
            var prevAssigned = ship.AssignedManeuver;
            IEnumerator routine = pred.CalculateMovementPredicition();
            try
            {
                Selection.ThisShip = ship;
                ship.SetAssignedManeuver(mv, isSilent: true);
                if (!routine.MoveNext()) return null;
                return routine;
            }
            catch (Exception e)
            {
                Plugin.Log.LogWarning("Prediction failed for " + mv.GetType().Name + ": " + e.Message);
                try { ship.ToggleColliders(true); MovementTemplates.HideLastMovementRuler(); } catch { }
                return null;
            }
            finally
            {
                if (prevAssigned != null) ship.SetAssignedManeuver(prevAssigned, isSilent: true);
                else ship.ClearAssignedManeuver();
                Selection.ThisShip = prevSelected;
            }
        }

        private static bool SafeMoveNext(IEnumerator routine, GenericShip ship)
        {
            try { return routine.MoveNext(); }
            catch (Exception e)
            {
                Plugin.Log.LogWarning("Prediction step failed: " + e.Message);
                try { ship.ToggleColliders(true); } catch { }
                return false;
            }
        }

        private static string Title(GenericMovement mv)
        {
            string b = mv.Bearing.ToString();
            string d = mv.Direction == ManeuverDirection.Forward ? "" : mv.Direction + " ";
            if (b == "Stationary") return "0 Stop";
            return mv.Speed + " " + d + Regex.Replace(b, "(\\B[A-Z])", " $1");
        }

        private void Build(Ghost g, GenericShip ship, GenericMovement mv, MovementPrediction pred, List<Pose> poses, string title)
        {
            var notes = new List<string>();
            Color c = ColClear;
            if (pred.IsOffTheBoard) { c = ColFail; notes.Add("FLIES OFF THE BOARD"); }
            if (pred.IsBumped)
            {
                if (c != ColFail) c = ColBump;
                var ids = new List<string>();
                foreach (var s in pred.ShipsBumped) ids.Add("#" + s.ShipId);
                notes.Add("bumps " + string.Join(", ", ids));
            }
            if (pred.IsLandedOnAsteroid) { if (c == ColClear || c == ColBump) c = ColHazard; notes.Add("lands on obstacle"); }
            else if (pred.AsteroidsHit.Count > 0) { if (c == ColClear || c == ColBump) c = ColHazard; notes.Add("flies over " + pred.AsteroidsHit.Count + " obstacle(s)"); }
            if (pred.MinesHit.Count > 0) { if (c == ColClear || c == ColBump) c = ColHazard; notes.Add("hits " + pred.MinesHit.Count + " device(s)"); }
            if (pred.ShipsMovedThrough.Count > 0) notes.Add("passes over " + pred.ShipsMovedThrough.Count + " ship(s)");
            if (notes.Count == 0) notes.Add("clear");

            var final = pred.FinalPositionInfo;
            var rot = Quaternion.Euler(final.Angles);
            float half = ship.ShipBase.HALF_OF_SHIPSTAND_SIZE;

            var root = new GameObject("QoLGhost " + ship.ShipId + " " + title);
            root.transform.SetPositionAndRotation(final.Position, rot);

            // Ship silhouette: copies of the model's visible meshes.
            var model = ship.Model.transform;
            var shipRoot = new GameObject("Ship");
            shipRoot.transform.SetParent(root.transform, false);
            shipRoot.transform.localScale = model.lossyScale;
            var shipMat = Gfx.Mat(new Color(c.r, c.g, c.b, Plugin.GhostOpacity.Value));
            Matrix4x4 toLocal = model.worldToLocalMatrix;
            foreach (var r in ship.Model.GetComponentsInChildren<Renderer>(false))
            {
                if (!r.enabled || r.GetComponent<TextMesh>() != null) continue;
                Mesh mesh = null;
                if (r is MeshRenderer) { var mf = r.GetComponent<MeshFilter>(); if (mf != null) mesh = mf.sharedMesh; }
                else if (r is SkinnedMeshRenderer smr) mesh = smr.sharedMesh;
                if (mesh == null) continue;
                Matrix4x4 rel = toLocal * r.transform.localToWorldMatrix;
                var part = new GameObject(r.name);
                part.transform.SetParent(shipRoot.transform, false);
                part.transform.localPosition = rel.GetColumn(3);
                part.transform.localRotation = rel.rotation;
                part.transform.localScale = rel.lossyScale;
                part.AddComponent<MeshFilter>().sharedMesh = mesh;
                var mr = part.AddComponent<MeshRenderer>();
                var arr = new Material[Mathf.Max(1, mesh.subMeshCount)];
                for (int i = 0; i < arr.Length; i++) arr[i] = shipMat;
                mr.sharedMaterials = arr;
                mr.shadowCastingMode = ShadowCastingMode.Off;
                mr.receiveShadows = false;
            }

            // Base footprint outline.
            var outline = new GameObject("Base").AddComponent<LineRenderer>();
            outline.transform.SetParent(root.transform, false);
            outline.useWorldSpace = false;
            outline.loop = true;
            outline.positionCount = 4;
            float y = 0.012f;
            outline.SetPositions(new[] { new Vector3(-half, y, 0), new Vector3(half, y, 0), new Vector3(half, y, -2 * half), new Vector3(-half, y, -2 * half) });
            outline.widthMultiplier = 0.018f;
            outline.sharedMaterial = Gfx.Mat(new Color(c.r, c.g, c.b, 0.95f));
            outline.shadowCastingMode = ShadowCastingMode.Off;

            // Flight path through base centers, trimmed at the bump point.
            if (poses != null && poses.Count > 1)
            {
                int n = Mathf.Clamp(Mathf.RoundToInt(pred.SuccessfullMovementProgress * (poses.Count - 1)) + 1, 2, poses.Count);
                var pts = new List<Vector3>();
                int stride = Mathf.Max(1, n / 40);
                for (int i = 0; i < n; i += stride) pts.Add(poses[i].position + poses[i].rotation * new Vector3(0, 0, -half) + Vector3.up * 0.02f);
                var lastP = poses[n - 1];
                pts.Add(lastP.position + lastP.rotation * new Vector3(0, 0, -half) + Vector3.up * 0.02f);
                var path = new GameObject("Path").AddComponent<LineRenderer>();
                path.transform.SetParent(root.transform, true);
                path.useWorldSpace = true;
                path.positionCount = pts.Count;
                path.SetPositions(pts.ToArray());
                path.widthMultiplier = 0.012f;
                path.sharedMaterial = Gfx.Mat(new Color(c.r, c.g, c.b, 0.75f));
                path.shadowCastingMode = ShadowCastingMode.Off;
            }

            root.SetActive(false);
            g.root = root;
            g.labelPos = final.Position + rot * new Vector3(0, 0, -half) + Vector3.up * 0.25f;
            g.title = title;
            g.outcome = string.Join(" · ", notes);
            g.color = c;
            g.ready = true;
        }

        private readonly List<Text> labels = new List<Text>();

        private void LateUpdate()
        {
            int idx = 0;
            try
            {
                if (wanted.Count > 0 && Nameplates.GetCam(ref cam) != null)
                {
                    foreach (var id in wanted)
                    {
                        if (!cache.TryGetValue(id, out var g) || !g.ready) continue;
                        Vector3 sp = cam.WorldToScreenPoint(g.labelPos);
                        if (sp.z <= 0 || !Overlay.ScreenToLocal(sp, out var local)) continue;
                        while (labels.Count <= idx)
                        {
                            var t = Overlay.NewText(Overlay.Rect, "GhostLabel", Plugin.NameplateFontSize.Value, FontStyle.Bold);
                            var rt = t.rectTransform;
                            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
                            rt.pivot = new Vector2(0.5f, 0f);
                            t.alignment = TextAnchor.LowerCenter;
                            var o = t.gameObject.AddComponent<Outline>();
                            o.effectColor = new Color(0, 0, 0, 0.9f);
                            labels.Add(t);
                        }
                        var label = labels[idx++];
                        label.fontSize = Plugin.NameplateFontSize.Value;
                        label.text = g.title + "\n" + g.outcome;
                        label.color = Color.Lerp(Color.white, g.color, 0.55f);
                        label.rectTransform.anchoredPosition = local;
                        label.rectTransform.sizeDelta = new Vector2(label.preferredWidth + 8, label.preferredHeight + 4);
                        if (!label.gameObject.activeSelf) label.gameObject.SetActive(true);
                    }
                }
            }
            catch (Exception e)
            {
                if (!errorLogged) { Plugin.Log.LogWarning("ManeuverPreview labels: " + e); errorLogged = true; }
            }
            for (int i = idx; i < labels.Count; i++) if (labels[i] != null && labels[i].gameObject.activeSelf) labels[i].gameObject.SetActive(false);
        }
    }
}
