using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace FlyCasualQoL
{
    // Scales every CanvasScaler in the scene by Plugin.UiScale. The game reads
    // GameObject "UI".localScale for its own layout math, so canvas scaling stays consistent.
    public class UiScaler : MonoBehaviour
    {
        private struct Orig { public Vector2 refRes; public float scaleFactor; public CanvasScaler.ScaleMode mode; }

        private readonly Dictionary<int, Orig> originals = new Dictionary<int, Orig>();
        private float nextScan;
        private float lastApplied = -1f;
        private bool loggedModes;

        private void Update()
        {
            float s = Plugin.UiScale.Value;
            bool changed = Mathf.Abs(s - lastApplied) > 0.0001f;
            if (!changed && Time.unscaledTime < nextScan) return;
            nextScan = Time.unscaledTime + 1f;
            lastApplied = s;

            try
            {
                foreach (var canvas in FindObjectsByType<Canvas>(FindObjectsSortMode.None))
                {
                    if (canvas.isRootCanvas && canvas.renderMode != RenderMode.WorldSpace && canvas.GetComponent<CanvasScaler>() == null)
                    {
                        var added = canvas.gameObject.AddComponent<CanvasScaler>();
                        added.uiScaleMode = CanvasScaler.ScaleMode.ConstantPixelSize;
                        added.scaleFactor = 1f;
                        changed = true;
                    }
                }
                foreach (var scaler in FindObjectsByType<CanvasScaler>(FindObjectsInactive.Include, FindObjectsSortMode.None))
                {
                    if (scaler.gameObject.name == Overlay.Name) continue;
                    int id = scaler.GetInstanceID();
                    if (!originals.TryGetValue(id, out var o))
                    {
                        o = new Orig { refRes = scaler.referenceResolution, scaleFactor = scaler.scaleFactor, mode = scaler.uiScaleMode };
                        originals[id] = o;
                        if (!loggedModes) Plugin.Log.LogInfo($"CanvasScaler '{scaler.name}': {o.mode} ref={o.refRes} factor={o.scaleFactor}");
                    }
                    else if (!changed) continue;

                    switch (o.mode)
                    {
                        case CanvasScaler.ScaleMode.ScaleWithScreenSize:
                            scaler.referenceResolution = o.refRes / s;
                            break;
                        case CanvasScaler.ScaleMode.ConstantPixelSize:
                            scaler.scaleFactor = o.scaleFactor * s;
                            break;
                        default:
                            scaler.uiScaleMode = CanvasScaler.ScaleMode.ConstantPixelSize;
                            scaler.scaleFactor = s;
                            break;
                    }
                }
                loggedModes = true;
            }
            catch (System.Exception e)
            {
                Plugin.Log.LogWarning("UiScaler: " + e.Message);
            }
        }
    }
}
