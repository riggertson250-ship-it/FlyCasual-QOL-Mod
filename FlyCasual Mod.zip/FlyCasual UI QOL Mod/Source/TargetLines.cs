using System.Collections.Generic;
using BoardTools;
using MainPhases;
using Ship;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

namespace FlyCasualQoL
{
    // Arrows on the board: attacker -> target during combat (with range), a preview arrow to any
    // hovered ship while choosing a target, and thin arrows for active target locks.
    public class TargetLines : MonoBehaviour
    {
        private class Arrow
        {
            public GameObject go;
            public LineRenderer line;
            public Transform head;
            public MeshRenderer headRenderer;
        }

        private struct Want
        {
            public GenericShip from, to;
            public Color color;
            public float width;
            public bool label;
        }

        private readonly List<Arrow> pool = new List<Arrow>();
        private readonly List<Want> wants = new List<Want>();
        private readonly List<(GenericShip a, GenericShip b)> locks = new List<(GenericShip, GenericShip)>();
        private readonly Dictionary<(int, int), int> rangeCache = new Dictionary<(int, int), int>();
        private readonly List<Text> labels = new List<Text>();
        private Mesh headMesh;
        private Camera cam;
        private float nextLockScan, lastBoardHash;
        private bool errorLogged;

        private void LateUpdate()
        {
            try { Tick(); }
            catch (System.Exception e)
            {
                if (!errorLogged) { Plugin.Log.LogWarning("TargetLines: " + e); errorLogged = true; }
                HideFrom(0, 0);
            }
        }

        private void Tick()
        {
            wants.Clear();
            pool.RemoveAll(a => a.go == null); // scene reload
            if (Roster.AllUnits == null || Roster.AllUnits.Count == 0) { HideFrom(0, 0); return; }

            var phase = Phases.CurrentPhase;
            var sub = Phases.CurrentSubPhase;
            var me = Selection.ThisShip;
            var hovered = Selection.HoveredShip;

            if (Plugin.TargetingLines.Value && me != null && !me.IsDestroyed)
            {
                var target = Selection.AnotherShip;
                bool choosing = phase is CombatPhase || sub is SubPhases.SelectShipSubPhase;
                if (phase is CombatPhase && Valid(target) && target != me)
                    wants.Add(new Want { from = me, to = target, color = WithA(Nameplates.PlayerColor(me), 0.95f), width = 0.03f, label = true });
                if (choosing && Valid(hovered) && hovered != me && hovered != target)
                    wants.Add(new Want { from = me, to = hovered, color = new Color(1f, 1f, 1f, 0.55f), width = 0.018f, label = true });
            }

            if (Plugin.LockLines.Value)
            {
                if (Time.unscaledTime >= nextLockScan) { ScanLocks(); nextLockScan = Time.unscaledTime + 0.3f; }
                foreach (var (a, b) in locks)
                {
                    if (!Valid(a) || !Valid(b)) continue;
                    bool hot = a == hovered || b == hovered || UI.ShowShipIds;
                    wants.Add(new Want { from = a, to = b, color = WithA(Nameplates.PlayerColor(a), hot ? 0.85f : 0.3f), width = hot ? 0.016f : 0.01f });
                }
            }

            // Ranges change only when ships move.
            float h = 0;
            foreach (var kv in Roster.AllUnits) if (kv.Value?.Model != null) { var p = kv.Value.GetPosition(); h += p.x * 1.7f + p.z * 2.3f + kv.Value.GetAngles().y * 0.01f; }
            if (Mathf.Abs(h - lastBoardHash) > 0.0001f) { lastBoardHash = h; rangeCache.Clear(); }

            GetCam_();
            int labelIdx = 0;
            for (int i = 0; i < wants.Count; i++)
            {
                var w = wants[i];
                if (i >= pool.Count) pool.Add(NewArrow());
                Draw(pool[i], w);
                if (w.label && cam != null) DrawLabel(labelIdx++, w);
            }
            HideFrom(wants.Count, labelIdx);
        }

        private void GetCam_() => Nameplates.GetCam(ref cam);

        private static bool Valid(GenericShip s) => s != null && !s.IsDestroyed && s.Model != null && !(s is Remote.GenericRemote);
        private static Color WithA(Color c, float a) { c.a = a; return c; }

        private void ScanLocks()
        {
            locks.Clear();
            foreach (var a in Roster.AllUnits.Values)
            {
                if (!Valid(a)) continue;
                foreach (var b in Roster.AllUnits.Values)
                {
                    if (b == a || !Valid(b)) continue;
                    var pairs = a.GetTargetLockLetterPairsOn(b);
                    if (pairs != null && pairs.Count > 0) locks.Add((a, b));
                }
            }
        }

        private Arrow NewArrow()
        {
            if (headMesh == null) headMesh = Gfx.ArrowHead();
            var a = new Arrow { go = new GameObject("QoLArrow") };
            a.line = a.go.AddComponent<LineRenderer>();
            a.line.useWorldSpace = true;
            a.line.positionCount = 2;
            a.line.numCapVertices = 2;
            a.line.shadowCastingMode = ShadowCastingMode.Off;
            a.line.receiveShadows = false;
            var head = new GameObject("Head");
            head.transform.SetParent(a.go.transform, false);
            head.AddComponent<MeshFilter>().sharedMesh = headMesh;
            a.headRenderer = head.AddComponent<MeshRenderer>();
            a.headRenderer.shadowCastingMode = ShadowCastingMode.Off;
            a.head = head.transform;
            return a;
        }

        private static void Draw(Arrow a, Want w)
        {
            if (!a.go.activeSelf) a.go.SetActive(true);
            Vector3 p0 = w.from.GetCenter(), p1 = w.to.GetCenter();
            float y = Mathf.Max(p0.y, p1.y) + 0.06f;
            p0.y = p1.y = y;
            Vector3 dir = p1 - p0;
            float len = dir.magnitude;
            if (len < 0.001f) { a.go.SetActive(false); return; }
            dir /= len;
            float startTrim = w.from.ShipBase.HALF_OF_SHIPSTAND_SIZE * 0.8f;
            float endTrim = w.to.ShipBase.HALF_OF_SHIPSTAND_SIZE * 0.9f;
            Vector3 s = p0 + dir * Mathf.Min(startTrim, len * 0.3f);
            Vector3 tip = p1 - dir * Mathf.Min(endTrim, len * 0.3f);
            float headLen = w.width * 6f;
            Vector3 e = tip - dir * headLen;

            var mat = Gfx.Mat(w.color, true);
            a.line.sharedMaterial = mat;
            a.line.widthMultiplier = w.width;
            a.line.SetPosition(0, s);
            a.line.SetPosition(1, e);
            a.headRenderer.sharedMaterial = mat;
            a.head.position = tip;
            a.head.rotation = Quaternion.LookRotation(dir, Vector3.up);
            a.head.localScale = new Vector3(w.width * 5f, 1f, headLen);
        }

        private void DrawLabel(int idx, Want w)
        {
            while (labels.Count <= idx)
            {
                var t = Overlay.NewText(Overlay.Rect, "RangeLabel", Plugin.NameplateFontSize.Value, FontStyle.Bold);
                var rt = t.rectTransform;
                rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
                t.alignment = TextAnchor.MiddleCenter;
                var outline = t.gameObject.AddComponent<Outline>();
                outline.effectColor = new Color(0, 0, 0, 0.9f);
                labels.Add(t);
            }
            var label = labels[idx];
            Vector3 mid = (w.from.GetCenter() + w.to.GetCenter()) * 0.5f + Vector3.up * 0.1f;
            Vector3 sp = cam.WorldToScreenPoint(mid);
            if (sp.z <= 0 || !Overlay.ScreenToLocal(sp, out var local)) { label.gameObject.SetActive(false); return; }

            var key = (w.from.ShipId, w.to.ShipId);
            if (!rangeCache.TryGetValue(key, out int range))
            {
                try { range = new DistanceInfo(w.from, w.to).Range; } catch { range = -1; }
                rangeCache[key] = range;
            }
            label.text = range < 0 ? "" : (range > 3 ? "Out of range" : "Range " + range);
            label.fontSize = Plugin.NameplateFontSize.Value;
            label.color = Color.Lerp(Color.white, w.color, 0.35f);
            label.rectTransform.anchoredPosition = local;
            label.rectTransform.sizeDelta = new Vector2(label.preferredWidth + 8, label.fontSize + 6);
            if (!label.gameObject.activeSelf) label.gameObject.SetActive(true);
        }

        private void HideFrom(int arrowIdx, int labelIdx)
        {
            for (int i = arrowIdx; i < pool.Count; i++) if (pool[i].go != null && pool[i].go.activeSelf) pool[i].go.SetActive(false);
            for (int i = labelIdx; i < labels.Count; i++) if (labels[i] != null && labels[i].gameObject.activeSelf) labels[i].gameObject.SetActive(false);
        }
    }
}
