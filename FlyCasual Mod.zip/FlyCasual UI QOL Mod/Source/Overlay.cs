using UnityEngine;
using UnityEngine.UI;

namespace FlyCasualQoL
{
    // A screen canvas that always sorts one step below the game's own "UI" canvas,
    // so anything drawn here sits underneath the game's HUD panels, dial and menus.
    internal static class Overlay
    {
        internal const string Name = "QoLOverlayCanvas";
        private static Canvas canvas;
        private static Canvas gameCanvas;
        private static Font font;
        private static Sprite whiteSprite;
        private static bool logged;

        internal static Canvas Canvas
        {
            get
            {
                if (canvas == null)
                {
                    var go = new GameObject(Name);
                    Object.DontDestroyOnLoad(go);
                    canvas = go.AddComponent<Canvas>();
                    canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                    var scaler = go.AddComponent<CanvasScaler>();
                    scaler.uiScaleMode = CanvasScaler.ScaleMode.ConstantPixelSize;
                    scaler.scaleFactor = 1f;
                }
                Sync();
                return canvas;
            }
        }

        internal static RectTransform Rect => (RectTransform)Canvas.transform;

        private static void Sync()
        {
            if (gameCanvas == null)
            {
                var ui = GameObject.Find("UI");
                gameCanvas = ui != null ? ui.GetComponent<Canvas>() : null;
                if (gameCanvas != null && !logged)
                {
                    logged = true;
                    Plugin.Log.LogInfo($"Game UI canvas: {gameCanvas.renderMode} order={gameCanvas.sortingOrder} layer={gameCanvas.sortingLayerName}");
                }
            }
            if (gameCanvas == null) return;
            if (canvas.renderMode != gameCanvas.renderMode) canvas.renderMode = gameCanvas.renderMode;
            if (gameCanvas.renderMode == RenderMode.ScreenSpaceCamera)
            {
                canvas.worldCamera = gameCanvas.worldCamera;
                canvas.planeDistance = gameCanvas.planeDistance + 0.01f;
            }
            canvas.sortingLayerID = gameCanvas.sortingLayerID;
            canvas.sortingOrder = gameCanvas.sortingOrder - 1;
        }

        internal static Camera UiCamera => Canvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : canvas.worldCamera;

        internal static bool ScreenToLocal(Vector2 screen, out Vector2 local)
            => RectTransformUtility.ScreenPointToLocalPointInRectangle(Rect, screen, UiCamera, out local);

        internal static Font Font
        {
            get
            {
                if (font != null) return font;
                try { font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } catch { }
                if (font == null)
                {
                    var t = Object.FindAnyObjectByType<Text>();
                    if (t != null) font = t.font;
                }
                return font;
            }
        }

        internal static Sprite White
        {
            get
            {
                if (whiteSprite != null) return whiteSprite;
                var tex = new Texture2D(2, 2);
                tex.SetPixels(new[] { Color.white, Color.white, Color.white, Color.white });
                tex.Apply();
                whiteSprite = Sprite.Create(tex, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
                return whiteSprite;
            }
        }

        internal static Image NewImage(Transform parent, string name)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var img = go.AddComponent<Image>();
            img.sprite = White;
            img.raycastTarget = false;
            var rt = (RectTransform)go.transform;
            rt.anchorMin = rt.anchorMax = new Vector2(0, 1);
            rt.pivot = new Vector2(0, 1);
            return img;
        }

        internal static Text NewText(Transform parent, string name, int size, FontStyle style)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var t = go.AddComponent<Text>();
            t.font = Font;
            t.fontSize = size;
            t.fontStyle = style;
            t.raycastTarget = false;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.alignment = TextAnchor.UpperLeft;
            var sh = go.AddComponent<Shadow>();
            sh.effectColor = new Color(0, 0, 0, 0.8f);
            sh.effectDistance = new Vector2(1, -1);
            var rt = (RectTransform)go.transform;
            rt.anchorMin = rt.anchorMax = new Vector2(0, 1);
            rt.pivot = new Vector2(0, 1);
            return t;
        }

        internal static void Place(RectTransform rt, float x, float y, float w, float h)
        {
            rt.anchoredPosition = new Vector2(x, -y);
            rt.sizeDelta = new Vector2(w, h);
        }
    }
}
