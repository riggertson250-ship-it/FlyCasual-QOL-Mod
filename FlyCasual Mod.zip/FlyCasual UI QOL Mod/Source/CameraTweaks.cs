using System;
using System.Reflection;
using HarmonyLib;
using MainPhases;
using Ship;
using UnityEngine;

namespace FlyCasualQoL
{
    internal static class CamAccess
    {
        internal static readonly FieldInfo CameraField = AccessTools.Field(typeof(CameraScript), "Camera");
        internal static readonly FieldInfo HolderField = AccessTools.Field(typeof(CameraScript), "CameraHolder");
        internal static readonly FieldInfo ModeField = AccessTools.Field(typeof(CameraScript), "cameraMode");
        internal static readonly FieldInfo OldState = AccessTools.Field(typeof(CameraScript), "OldCameraState");
        internal static readonly FieldInfo NewState = AccessTools.Field(typeof(CameraScript), "NewCameraState");
        internal static readonly FieldInfo Counter = AccessTools.Field(typeof(CameraScript), "TransitionTimeCounter");
        internal static readonly MethodInfo ZoomByFactor = AccessTools.Method(typeof(CameraScript), "ZoomByFactor");
        internal static readonly MethodInfo ClampRotation = AccessTools.Method(typeof(CameraScript), "CamClampRotation");
        internal static readonly MethodInfo SetDefault = AccessTools.Method(typeof(CameraScript), "SetDefaultCameraPosition");

        internal static Transform Cam => CameraField.GetValue(null) as Transform;
        internal static Transform Holder => HolderField.GetValue(null) as Transform;
        internal static bool TopDown => Convert.ToInt32(ModeField.GetValue(null)) != 0;
    }

    [HarmonyPatch(typeof(CameraScript), "CamMoveByMouse")]
    internal static class Patch_EdgeScroll
    {
        private static bool Prefix() => Plugin.EdgeScrolling.Value;
    }

    [HarmonyPatch(typeof(CameraScript), "CamMoveByAxis")]
    internal static class Patch_Pan
    {
        private static bool Prefix(CameraScript __instance)
        {
            if (global::Console.IsActive || Input.GetKey(KeyCode.LeftControl)) return false;
            float x = 0, y = 0;
            if (DebugManager.AlternativeCameraControls)
            {
                x = Mathf.Clamp(Input.GetAxis("Horizontal"), -1, 1);
                y = Mathf.Clamp(Input.GetAxis("Vertical"), -1, 1);
            }
            else
            {
                if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) x -= 1;
                if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) x += 1;
                if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) y -= 1;
                if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) y += 1;
            }
            if (x == 0 && y == 0) return false;

            float speed = 0.125f * Plugin.PanSpeed.Value * (Input.GetKey(KeyCode.LeftShift) ? 3f : 1f);
            if (Plugin.ZoomScaledPan.Value)
            {
                float zoomT;
                if (CamAccess.TopDown)
                {
                    var c = CamAccess.Cam.GetComponent<Camera>();
                    zoomT = Mathf.InverseLerp(1f, 6f, c.orthographicSize);
                }
                else zoomT = Mathf.InverseLerp(1.5f, 8f, __instance.transform.position.y);
                speed *= Mathf.Lerp(0.35f, 1.35f, zoomT) * Mathf.Clamp(Time.unscaledDeltaTime * 60f, 0.25f, 3f);
            }
            CameraTweaks.CancelGlide();
            UI.HideTemporaryMenus();
            __instance.transform.Translate(x * speed, y * speed, 0f);
            return false;
        }
    }

    [HarmonyPatch(typeof(CameraScript), "CamZoomByMouseScroll")]
    internal static class Patch_Zoom
    {
        private static bool Prefix(CameraScript __instance)
        {
            float z = Input.GetAxis("Mouse ScrollWheel") * 5f * Plugin.ZoomSensitivity.Value;
            if (z == 0f) return false;
            if (Plugin.SmoothZoom.Value) CameraTweaks.PendingZoom += z;
            else CamAccess.ZoomByFactor.Invoke(__instance, new object[] { z });
            return false;
        }
    }

    [HarmonyPatch(typeof(CameraScript), "CamRotateByMouse")]
    internal static class Patch_Rotate
    {
        private static bool Prefix(CameraScript __instance)
        {
            if (CamAccess.TopDown || !(Input.GetKey(KeyCode.Mouse1) || Input.GetKey(KeyCode.Mouse2))) return false;
            float s = 5f * Plugin.RotateSensitivity.Value;
            float turnX = Input.GetAxis("Mouse Y") * -s;
            turnX = (float)CamAccess.ClampRotation.Invoke(__instance, new object[] { turnX });
            CamAccess.Cam.Rotate(turnX, 0f, 0f);
            float turnY = Input.GetAxis("Mouse X") * -s;
            __instance.transform.Rotate(0f, 0f, turnY);
            if (turnX != 0f || turnY != 0f) { CameraTweaks.CancelGlide(); UI.HideTemporaryMenus(); }
            return false;
        }
    }

    // Eased, configurable-duration version of the cinematic flight.
    [HarmonyPatch(typeof(CameraScript), "DoCameraTransition")]
    internal static class Patch_Transition
    {
        private static bool Prefix(CameraState oldCamera, CameraState newCamera)
        {
            float t = (float)CamAccess.Counter.GetValue(null);
            if (t >= 1f) return false;
            float e = Mathf.SmoothStep(0f, 1f, t);
            CameraScript.SetPosition(Vector3.Lerp(oldCamera.CameraHolderPosition, newCamera.CameraHolderPosition, e), Vector3.zero);
            CamAccess.Cam.LookAt(Vector3.Lerp(oldCamera.LookAtPosition, newCamera.LookAtPosition, e), Vector3.up);
            t += Mathf.Min(Time.deltaTime / Mathf.Max(0.05f, Plugin.CinematicTransitionSeconds.Value), 1f - t);
            CamAccess.Counter.SetValue(null, t);
            return false;
        }
    }

    public class CameraTweaks : MonoBehaviour
    {
        internal static float PendingZoom;
        private static Vector3? glideTarget;
        private static Vector3 glideVel;
        private CameraScript camScript;
        private GenericShip lastActive;
        private bool errorLogged;

        internal static void CancelGlide() => glideTarget = null;

        private void Update()
        {
            try { Tick(); }
            catch (Exception e)
            {
                if (!errorLogged) { Plugin.Log.LogWarning("CameraTweaks: " + e); errorLogged = true; }
            }
        }

        private void Tick()
        {
            DebugManager.NoCinematicCamera = !Plugin.CinematicAttackCamera.Value;

            if (camScript == null) camScript = FindAnyObjectByType<CameraScript>();
            if (camScript == null || CamAccess.Cam == null) { PendingZoom = 0; glideTarget = null; return; }

            bool blocked = CameraScript.IsCinematic || DirectionsMenu.IsVisible;

            if (Mathf.Abs(PendingZoom) > 0.0005f && !blocked)
            {
                float step = PendingZoom * (1f - Mathf.Exp(-Time.unscaledDeltaTime * 14f));
                CamAccess.ZoomByFactor.Invoke(camScript, new object[] { step });
                PendingZoom -= step;
            }
            else if (Mathf.Abs(PendingZoom) <= 0.0005f) PendingZoom = 0;

            if (!Plugin.TypingInField() && !blocked)
            {
                if (Input.GetKeyDown(Plugin.ResetViewKey.Value))
                {
                    glideTarget = null; PendingZoom = 0;
                    CamAccess.SetDefault.Invoke(null, null);
                }
                if (Input.GetKeyDown(Plugin.FocusKey.Value) && Selection.ThisShip != null)
                    FocusOn(Selection.ThisShip);
            }

            if (Plugin.FollowActiveShip.Value && !blocked)
            {
                var phase = Phases.CurrentPhase;
                var active = (phase is ActivationPhase || phase is CombatPhase) ? Selection.ThisShip : null;
                if (active != null && active != lastActive) FocusOn(active);
                lastActive = active;
            }

            if (glideTarget.HasValue && !blocked)
            {
                var holder = camScript.transform;
                holder.position = Vector3.SmoothDamp(holder.position, glideTarget.Value, ref glideVel, 0.28f, Mathf.Infinity, Time.unscaledDeltaTime);
                if ((holder.position - glideTarget.Value).sqrMagnitude < 0.0004f) glideTarget = null;
            }
        }

        private void FocusOn(GenericShip ship)
        {
            if (ship == null || ship.Model == null) return;
            var cam = CamAccess.Cam;
            var holder = camScript.transform;
            Vector3 target = ship.GetCenter();
            Vector3 look;
            if (CamAccess.TopDown || cam.forward.y > -0.05f)
                look = new Vector3(cam.position.x, target.y, cam.position.z);
            else
            {
                float d = (cam.position.y - target.y) / -cam.forward.y;
                look = cam.position + cam.forward * d;
            }
            Vector3 delta = target - look; delta.y = 0;
            Vector3 dest = holder.position + delta;
            dest.x = Mathf.Clamp(dest.x, -18f, 18f);
            dest.z = Mathf.Clamp(dest.z, -18f, 18f);
            glideTarget = dest;
            glideVel = Vector3.zero;
        }
    }
}
