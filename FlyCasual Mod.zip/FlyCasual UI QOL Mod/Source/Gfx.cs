using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace FlyCasualQoL
{
    internal static class Gfx
    {
        private static readonly Dictionary<(Color, bool), Material> mats = new Dictionary<(Color, bool), Material>();

        // Unlit alpha-blended material; onTop draws through ship models.
        internal static Material Mat(Color c, bool onTop = false)
        {
            if (mats.TryGetValue((c, onTop), out var m) && m != null) return m;
            var sh = Shader.Find("Hidden/Internal-Colored") ?? Shader.Find("Sprites/Default");
            m = new Material(sh) { hideFlags = HideFlags.HideAndDontSave, color = c, renderQueue = onTop ? 3100 : 3000 };
            m.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            m.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            m.SetInt("_Cull", (int)CullMode.Off);
            m.SetInt("_ZWrite", 0);
            if (onTop) m.SetInt("_ZTest", (int)CompareFunction.Always);
            mats[(c, onTop)] = m;
            return m;
        }

        internal static Mesh ArrowHead()
        {
            var mesh = new Mesh();
            mesh.vertices = new[] { new Vector3(0, 0, 0), new Vector3(-0.5f, 0, -1f), new Vector3(0.5f, 0, -1f) };
            mesh.triangles = new[] { 0, 1, 2 };
            mesh.RecalculateBounds();
            return mesh;
        }
    }
}
