using System;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace FlyCasualQoL
{
    public enum NameplateMode { HoverOnly, Always, AltOnly }

    [BepInPlugin(GUID, "Fly Casual QoL", VERSION)]
    public class Plugin : BaseUnityPlugin
    {
        public const string GUID = "tytan.flycasual.qol";
        public const string VERSION = "1.0.0";

        internal static ManualLogSource Log;
        internal static Plugin Instance;

        // UI
        internal static ConfigEntry<float> UiScale;
        internal static ConfigEntry<bool> NameplatesEnabled;
        internal static ConfigEntry<NameplateMode> NameplateStyle;
        internal static ConfigEntry<int> NameplateFontSize;
        internal static ConfigEntry<bool> ColorblindPalette;
        internal static ConfigEntry<bool> DimActivatedShips;
        internal static ConfigEntry<KeyCode> ToggleNameplatesKey;
        internal static ConfigEntry<bool> TargetingLines;
        internal static ConfigEntry<bool> LockLines;

        // Camera
        internal static ConfigEntry<bool> CinematicAttackCamera;
        internal static ConfigEntry<float> CinematicTransitionSeconds;
        internal static ConfigEntry<bool> EdgeScrolling;
        internal static ConfigEntry<float> PanSpeed;
        internal static ConfigEntry<bool> ZoomScaledPan;
        internal static ConfigEntry<bool> SmoothZoom;
        internal static ConfigEntry<float> ZoomSensitivity;
        internal static ConfigEntry<float> RotateSensitivity;
        internal static ConfigEntry<KeyCode> FocusKey;
        internal static ConfigEntry<KeyCode> ResetViewKey;
        internal static ConfigEntry<bool> FollowActiveShip;

        // Planning
        internal static ConfigEntry<bool> ManeuverPreview;
        internal static ConfigEntry<KeyCode> ShowAllPlansKey;
        internal static ConfigEntry<float> GhostOpacity;

        internal static ConfigEntry<KeyCode> SettingsKey;

        private bool showSettings;
        private Rect settingsRect = new Rect(40, 80, 360, 10);

        private void Awake()
        {
            Log = Logger;
            Instance = this;

            UiScale = Config.Bind("UI", "UiScale", 0.8f, new ConfigDescription("Multiplier for the game's whole UI (menus, rosters, maneuver dial). 1.0 = vanilla.", new AcceptableValueRange<float>(0.4f, 1.5f)));
            NameplatesEnabled = Config.Bind("UI", "Nameplates", true, "Floating labels over every ship (ID, pilot, hull/shields), colored by player.");
            NameplateStyle = Config.Bind("UI", "NameplateVisibility", NameplateMode.HoverOnly, "HoverOnly: a ship's label appears when you hover it (and for the attacker/defender during combat). Always: every ship. AltOnly: only while holding Left Alt. Left Alt always shows all.");
            NameplateFontSize = Config.Bind("UI", "NameplateFontSize", 13, new ConfigDescription("Nameplate text size.", new AcceptableValueRange<int>(9, 24)));
            ColorblindPalette = Config.Bind("UI", "ColorblindPalette", false, "Use blue/orange instead of green/red for player colors.");
            DimActivatedShips = Config.Bind("UI", "DimActivatedShips", true, "Fade nameplates of ships that already moved (activation) or attacked (combat).");
            ToggleNameplatesKey = Config.Bind("UI", "ToggleNameplatesKey", KeyCode.F6, "Toggle nameplates on/off.");
            TargetingLines = Config.Bind("UI", "TargetingLines", true, "Draw an arrow from attacker to target during combat, with the range, and a preview line to any ship you hover while choosing a target.");
            LockLines = Config.Bind("UI", "LockLines", true, "Draw thin arrows for active target locks (brighter when either ship is hovered).");

            CinematicAttackCamera = Config.Bind("Camera", "CinematicAttackCamera", false, "Fly the camera behind the attacker on every attack (vanilla behaviour).");
            CinematicTransitionSeconds = Config.Bind("Camera", "CinematicTransitionSeconds", 1.0f, new ConfigDescription("Duration of the eased attack-camera flight (vanilla is a 2s linear move).", new AcceptableValueRange<float>(0.2f, 3f)));
            EdgeScrolling = Config.Bind("Camera", "EdgeScrolling", false, "Pan when the mouse touches the screen edge (vanilla on; causes accidental drifting).");
            PanSpeed = Config.Bind("Camera", "PanSpeed", 1.0f, new ConfigDescription("WASD/arrow pan speed multiplier.", new AcceptableValueRange<float>(0.2f, 3f)));
            ZoomScaledPan = Config.Bind("Camera", "ZoomScaledPan", true, "Pan slower when zoomed in, faster when zoomed out. Also makes panning frame-rate independent.");
            SmoothZoom = Config.Bind("Camera", "SmoothZoom", true, "Ease mouse-wheel zoom instead of jumping.");
            ZoomSensitivity = Config.Bind("Camera", "ZoomSensitivity", 0.6f, new ConfigDescription("Mouse-wheel zoom multiplier (vanilla 1.0).", new AcceptableValueRange<float>(0.1f, 2f)));
            RotateSensitivity = Config.Bind("Camera", "RotateSensitivity", 0.6f, new ConfigDescription("Right/middle-drag rotate multiplier (vanilla 1.0).", new AcceptableValueRange<float>(0.1f, 2f)));
            FocusKey = Config.Bind("Camera", "FocusKey", KeyCode.F, "Glide the camera to the selected ship.");
            ResetViewKey = Config.Bind("Camera", "ResetViewKey", KeyCode.Home, "Snap back to the default view for your side.");
            FollowActiveShip = Config.Bind("Camera", "FollowActiveShip", false, "Automatically glide to each ship as it activates during movement and combat.");

            ManeuverPreview = Config.Bind("Planning", "ManeuverPreview", true, "Hover a maneuver on the dial to see a ghost of the ship at its end position, with bump/obstacle/off-board warnings.");
            ShowAllPlansKey = Config.Bind("Planning", "ShowAllPlansKey", KeyCode.G, "Hold during planning to show ghosts for all your ships' assigned dials.");
            GhostOpacity = Config.Bind("Planning", "GhostOpacity", 0.35f, new ConfigDescription("Ghost ship transparency.", new AcceptableValueRange<float>(0.1f, 0.8f)));

            SettingsKey = Config.Bind("General", "SettingsKey", KeyCode.F8, "Open the in-game settings panel.");

            new Harmony(GUID).PatchAll(typeof(Plugin).Assembly);

            gameObject.AddComponent<UiScaler>();
            gameObject.AddComponent<Nameplates>();
            gameObject.AddComponent<CameraTweaks>();
            gameObject.AddComponent<ManeuverPreview>();
            gameObject.AddComponent<TargetLines>();

            Log.LogInfo("Fly Casual QoL " + VERSION + " loaded");
        }

        internal static bool TypingInField()
        {
            try
            {
                if (global::Console.IsActive) return true;
                var es = EventSystem.current;
                if (es == null || es.currentSelectedGameObject == null) return false;
                return es.currentSelectedGameObject.GetComponent<InputField>() != null;
            }
            catch { return false; }
        }

        private void Update()
        {
            if (!TypingInField() && Input.GetKeyDown(SettingsKey.Value)) showSettings = !showSettings;
        }

        private void OnGUI()
        {
            if (!showSettings) return;
            settingsRect.height = 0;
            settingsRect = GUILayout.Window(0x5143, settingsRect, DrawSettings, "Fly Casual QoL  (" + SettingsKey.Value + " to close)");
        }

        private static void Slider(string label, ConfigEntry<float> e, float min, float max)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(label, GUILayout.Width(170));
            float v = GUILayout.HorizontalSlider(e.Value, min, max, GUILayout.Width(120));
            GUILayout.Label(v.ToString("0.00"), GUILayout.Width(40));
            GUILayout.EndHorizontal();
            if (Math.Abs(v - e.Value) > 0.001f) e.Value = (float)Math.Round(v, 2);
        }

        private static void Toggle(string label, ConfigEntry<bool> e)
        {
            bool v = GUILayout.Toggle(e.Value, " " + label);
            if (v != e.Value) e.Value = v;
        }

        private void DrawSettings(int id)
        {
            GUILayout.Label("<b>UI</b>");
            Slider("UI scale", UiScale, 0.4f, 1.5f);
            Toggle("Ship nameplates (" + ToggleNameplatesKey.Value + ")", NameplatesEnabled);
            GUILayout.BeginHorizontal();
            GUILayout.Label("Nameplate mode", GUILayout.Width(170));
            if (GUILayout.Button(NameplateStyle.Value.ToString()))
                NameplateStyle.Value = (NameplateMode)(((int)NameplateStyle.Value + 1) % 3);
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Label("Nameplate size", GUILayout.Width(170));
            if (GUILayout.Button("-", GUILayout.Width(28))) NameplateFontSize.Value = Math.Max(9, NameplateFontSize.Value - 1);
            GUILayout.Label(NameplateFontSize.Value.ToString(), GUILayout.Width(30));
            if (GUILayout.Button("+", GUILayout.Width(28))) NameplateFontSize.Value = Math.Min(24, NameplateFontSize.Value + 1);
            GUILayout.EndHorizontal();
            Toggle("Colorblind player colors", ColorblindPalette);
            Toggle("Dim ships that already acted", DimActivatedShips);
            Toggle("Attack targeting lines", TargetingLines);
            Toggle("Target lock lines", LockLines);

            GUILayout.Space(6);
            GUILayout.Label("<b>Camera</b>");
            Toggle("Cinematic attack camera", CinematicAttackCamera);
            Slider("Attack cam flight (s)", CinematicTransitionSeconds, 0.2f, 3f);
            Toggle("Edge scrolling", EdgeScrolling);
            Toggle("Zoom-scaled panning", ZoomScaledPan);
            Slider("Pan speed", PanSpeed, 0.2f, 3f);
            Toggle("Smooth zoom", SmoothZoom);
            Slider("Zoom sensitivity", ZoomSensitivity, 0.1f, 2f);
            Slider("Rotate sensitivity", RotateSensitivity, 0.1f, 2f);
            Toggle("Auto-follow activating ship", FollowActiveShip);
            GUILayout.Label("Focus selected: " + FocusKey.Value + "    Reset view: " + ResetViewKey.Value);

            GUILayout.Space(6);
            GUILayout.Label("<b>Planning</b>");
            Toggle("Maneuver ghost preview (hover dial)", ManeuverPreview);
            Slider("Ghost opacity", GhostOpacity, 0.1f, 0.8f);
            GUILayout.Label("Hold " + ShowAllPlansKey.Value + " in planning: show all your dialed moves");

            GUI.DragWindow();
        }
    }
}
