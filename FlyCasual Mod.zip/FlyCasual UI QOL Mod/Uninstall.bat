@echo off
setlocal EnableExtensions EnableDelayedExpansion
title FlyCasual UI QOL Mod - Uninstaller
echo.
echo  ============================================
echo   FlyCasual UI QOL Mod v1.0.0 - Uninstaller
echo  ============================================
echo.

set "DEFAULT=Z:\Third Party Games\Star Wars Board Games\FlyCasual"
set "GAME="
if exist "%DEFAULT%\Fly Casual.exe" (
    echo  Found Fly Casual at:
    echo    %DEFAULT%
    set /p "USEDEF=  Uninstall from there? [Y/n]: "
    if /i not "!USEDEF!"=="n" set "GAME=%DEFAULT%"
)
if not defined GAME (
    echo  Paste the folder that contains "Fly Casual.exe" and press Enter:
    set /p "GAME=  > "
)
set "GAME=%GAME:"=%"
if "%GAME:~-1%"=="\" set "GAME=%GAME:~0,-1%"
if not exist "%GAME%\Fly Casual.exe" ( echo  ERROR: "Fly Casual.exe" not found in "%GAME%". & goto :end )

tasklist /FI "IMAGENAME eq Fly Casual.exe" 2>nul | find /I "Fly Casual.exe" >nul
if not errorlevel 1 ( echo  Close Fly Casual first, then run this again. & goto :end )

if exist "%GAME%\BepInEx\plugins\FlyCasualQoL" rmdir /S /Q "%GAME%\BepInEx\plugins\FlyCasualQoL"
if exist "%GAME%\BepInEx\config\tytan.flycasual.qol.cfg" del /Q "%GAME%\BepInEx\config\tytan.flycasual.qol.cfg"
echo  Mod removed.
echo.
echo  BepInEx (the mod loader) is still installed. Remove it too?
echo  Say N if you use other BepInEx mods with Fly Casual.
set /p "ALL=  Remove BepInEx completely? [y/N]: "
if /i "!ALL!"=="y" (
    if exist "%GAME%\BepInEx" rmdir /S /Q "%GAME%\BepInEx"
    for %%F in (winhttp.dll doorstop_config.ini .doorstop_version changelog.txt) do if exist "%GAME%\%%F" del /Q "%GAME%\%%F"
    echo  BepInEx removed. The game is back to vanilla.
)

:end
echo.
pause
